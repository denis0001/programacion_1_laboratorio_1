typedef struct
{
    int legajo;
    int nota1;
    int nota2;
    float promedio;
    char nombre[30];
    int estado;
}eAlumno;

void altaAlumno(eAlumno[], int);
void mostrarAlumnos(eAlumno[], int);
void ordenarAlumnos(eAlumno[], int);
void modificarAlumno(eAlumno[], int);
void eliminarAlumno(eAlumno[], int);
void mostrar(eAlumno);
